-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2011 at 08:07 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kedaionline_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

DROP TABLE IF EXISTS `tbl_cart`;
CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `cart_token` varchar(13) NOT NULL,
  `produk_token` varchar(13) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` decimal(18,2) NOT NULL,
  KEY `cart_token` (`cart_token`),
  KEY `produk_token` (`produk_token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tbl_cart_view`
--
DROP VIEW IF EXISTS `tbl_cart_view`;
CREATE TABLE IF NOT EXISTS `tbl_cart_view` (
`cart_token` varchar(13)
,`produk_token` varchar(13)
,`qty` int(11)
,`harga` decimal(18,2)
,`total` decimal(28,2)
);
-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

DROP TABLE IF EXISTS `tbl_kategori`;
CREATE TABLE IF NOT EXISTS `tbl_kategori` (
  `token` varchar(13) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  PRIMARY KEY (`token`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

DROP TABLE IF EXISTS `tbl_member`;
CREATE TABLE IF NOT EXISTS `tbl_member` (
  `token` varchar(13) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_id` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `tanggal_daftar` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` text NOT NULL,
  PRIMARY KEY (`token`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member_checkout`
--

DROP TABLE IF EXISTS `tbl_member_checkout`;
CREATE TABLE IF NOT EXISTS `tbl_member_checkout` (
  `token` varchar(13) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `member_token` varchar(13) NOT NULL,
  PRIMARY KEY (`token`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member_checkout_produk`
--

DROP TABLE IF EXISTS `tbl_member_checkout_produk`;
CREATE TABLE IF NOT EXISTS `tbl_member_checkout_produk` (
  `token` varchar(13) NOT NULL,
  `produk_token` varchar(13) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` decimal(18,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tbl_member_checkout_produk_view`
--
DROP VIEW IF EXISTS `tbl_member_checkout_produk_view`;
CREATE TABLE IF NOT EXISTS `tbl_member_checkout_produk_view` (
`token` varchar(13)
,`produk_token` varchar(13)
,`qty` int(11)
,`harga` decimal(18,2)
,`total` decimal(28,2)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `tbl_member_checkout_view`
--
DROP VIEW IF EXISTS `tbl_member_checkout_view`;
CREATE TABLE IF NOT EXISTS `tbl_member_checkout_view` (
`token` varchar(13)
,`id` int(11)
,`tanggal` timestamp
,`member_token` varchar(13)
,`total` decimal(50,2)
);
-- --------------------------------------------------------

--
-- Table structure for table `tbl_produk`
--

DROP TABLE IF EXISTS `tbl_produk`;
CREATE TABLE IF NOT EXISTS `tbl_produk` (
  `token` varchar(13) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` decimal(18,2) NOT NULL,
  `harga_spesial` decimal(18,2) DEFAULT NULL,
  `kategori_token` varchar(13) NOT NULL,
  PRIMARY KEY (`token`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_produk_image`
--

DROP TABLE IF EXISTS `tbl_produk_image`;
CREATE TABLE IF NOT EXISTS `tbl_produk_image` (
  `token` varchar(13) NOT NULL,
  `foto1` text,
  `foto2` text,
  `foto3` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_produk_image_binary`
--

DROP TABLE IF EXISTS `tbl_produk_image_binary`;
CREATE TABLE IF NOT EXISTS `tbl_produk_image_binary` (
  `token` varchar(13) NOT NULL,
  `foto1` longblob,
  `foto1_ext` varchar(20) DEFAULT NULL,
  `foto2` longblob,
  `foto2_ext` varchar(20) DEFAULT NULL,
  `foto3` longblob,
  `foto3_ext` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `token` varchar(13) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`token`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Structure for view `tbl_cart_view`
--
DROP TABLE IF EXISTS `tbl_cart_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tbl_cart_view` AS select `tbl_cart`.`cart_token` AS `cart_token`,`tbl_cart`.`produk_token` AS `produk_token`,`tbl_cart`.`qty` AS `qty`,`tbl_cart`.`harga` AS `harga`,(`tbl_cart`.`qty` * `tbl_cart`.`harga`) AS `total` from `tbl_cart`;

-- --------------------------------------------------------

--
-- Structure for view `tbl_member_checkout_produk_view`
--
DROP TABLE IF EXISTS `tbl_member_checkout_produk_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tbl_member_checkout_produk_view` AS select `tbl_member_checkout_produk`.`token` AS `token`,`tbl_member_checkout_produk`.`produk_token` AS `produk_token`,`tbl_member_checkout_produk`.`qty` AS `qty`,`tbl_member_checkout_produk`.`harga` AS `harga`,(`tbl_member_checkout_produk`.`qty` * `tbl_member_checkout_produk`.`harga`) AS `total` from `tbl_member_checkout_produk`;

-- --------------------------------------------------------

--
-- Structure for view `tbl_member_checkout_view`
--
DROP TABLE IF EXISTS `tbl_member_checkout_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tbl_member_checkout_view` AS select `a`.`token` AS `token`,`a`.`id` AS `id`,`a`.`tanggal` AS `tanggal`,`a`.`member_token` AS `member_token`,(select sum(`tbl_member_checkout_produk_view`.`total`) from `tbl_member_checkout_produk_view` where (`tbl_member_checkout_produk_view`.`token` = `a`.`token`)) AS `total` from `tbl_member_checkout` `a`;
